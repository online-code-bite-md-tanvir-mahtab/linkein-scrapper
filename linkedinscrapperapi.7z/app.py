from playwright.sync_api import sync_playwright, Playwright
from time import sleep
import pandas as pd

from flask import Flask, render_template, request, redirect


people_names = []
people_profile_url = []
people_job_company_names = []
datas = pd.DataFrame()



def run(playwright: Playwright):
    # Launch a browser (Chromium, Firefox, or WebKit)
    browser = playwright.firefox.launch(headless=True, executable_path='firefox-1449/firefox/firefox.exe')  # Set headless=True to run in headless mode
    # Create a new browser context
    context = browser.new_context()
    # Open a new page
    page = context.new_page()
    # Navigate to a URL
    page.goto("http://www.linkedin.com/")
    sleep(5)
    # Interact with the page (e.g., take a screenshot)
    # page.screenshot(path="screenshot.png")
    
    is_visible = page.locator(selector='a[data-tracking-control-name="guest_homepage-basic_guest_nav_menu_people"]').is_visible()
    sleep(3)
    if is_visible:
        people =  page.locator(selector='a[data-tracking-control-name="guest_homepage-basic_guest_nav_menu_people"]')
        people.click()
        sleep(5)
        
        
    f_name_feild_is_visible = page.locator(selector='input[name="firstName"]').is_visible()
    
    
    if f_name_feild_is_visible :
        f_name_feild = page.locator(selector='input[name="firstName"]')
        f_name_feild.click()
        sleep(2)
        f_name_feild.type('tanvir')
        sleep(2)
        page.locator(selector='button[data-tracking-control-name="people-guest_people-search-bar_base-search-bar-search-submit"]').click()
    
    
    sleep(5)
    items = page.query_selector_all(selector='li[class="pserp-layout__profile-result-list-item"]')
    sleep(5)
    for item in items:
        urls = ''
        name = ''
        company = ''
        try:
            urls = item.query_selector(selector='a').get_property('href')
        except :
            urls = "not found"
        try:
            name = item.query_selector(selector='h3[class="base-search-card__title"]').text_content().strip()
        except :
            name = ''
        try:
            company = item.query_selector(selector='span[class="entity-list-meta__entities-list"]').text_content().strip()
        except :
            company = "Not employeed"
        
        people_profile_url.append(urls)
        people_names.append(name)
        people_job_company_names.append(company)
        
    print("the application is finished")
    datas = pd.DataFrame(
            {
                'url':people_profile_url,
                'name': people_names,
                'company': people_job_company_names
            }
        )
    datas.to_csv('datas.csv',index=False)
    # Close the browser context and browser
    context.close()
    browser.close()

# with sync_playwright() as playwright:
#     run(playwright)



# ========fontend part========


app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)